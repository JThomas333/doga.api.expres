const film = 
[{cim: "Instant Family", rendezo:"Sean Anders", ev:"2023",oszakar:"nem"},
    {cim:"cim2", rendezo:"rendezo2", ev:"2000",oszkar:"igen"},
    {cim:"cim3", rendezo:"rendezo3", ev:"2005",oszkar:"igen"},
]

export default film