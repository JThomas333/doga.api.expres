import express from "express"
import _dirname from ".rootpath.js"
import path from "path"
import * as filekezel from ".fajlkezelo.js"

const app=express()
app.use(express.json())

app.get("/movies", (req,res)=>{
    const film = filekezel.getData()
    res.json(film)
})
app.get("/movies/:id", (req,res)=>{
    const film = filekezel.getData()
    const id = req.params.id
    if (id < 0 || id > film.lenght) {
        return res.json({})
    }
    res.json(film[id])
})
app.post("/movies", (req,res)=>{
    const {cim, rendezo, ev, oszkar} = req.body
    const uj = {cim, rendezo, ev, oszkar}
    const film = filekezel.getData()
    if (!cim || !rendezo || !ev || !oszkart) {
        return res.json({message: "nem jo"})
    }
    film.push(uj)
    filekezel.getSave(film)
    res.json(film)
})
app.put("/movies/:id", (req,res)=>{
    const id = req.params.id
    if (id < 0 || id > film.lenght) {
        return res.json({})
    }
    const film = filekezel.getData()
    const {cim, rendezo, ev, oszkar} = req.body
    if (!cim || !rendezo || !ev || !oszkart) {
        return res.json({message: "nem jo"})
    }
    film[id] = {cim, rendezo, ev, oszkar}
    filekezel.getSave(film)
    res.json(film[id])
})
app.patch("/movies/:id", (req,res)=>{
    const id = req.params.id
    if (id < 0 || id > film.lenght) {
        return res.json({})
    }
    const film = filekezel.getData()
    const {cim, rendezo, ev, oszkar} = req.body
    film[id] = {
        cim: cim || JSON.cim[id],
        rendezo: rendezo || JSON.rendezo[id],
        ev: ev || JSON.ev[id],
        oszkar: oszkar || JSON.oszkar[id],}
    filekezel.getSave(film)
    res.json(film[id])
})
app.delete("/movies/:id", (req,res)=>{
    const id = req.params.id
    if (id < 0 || id > film.lenght) {
        return res.json({})
    }
    const film = filekezel.getData()
    film.splice(id,1)
    filekezel.getSave(film)
    res.json(film)
})

app.listen(3000, () =>{
    console.log("Server on")
})