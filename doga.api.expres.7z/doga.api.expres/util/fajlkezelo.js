import path from "path"
import fs from "fs"
import _dirname from "/rootpath.js"

const filePath = path.join(_dirname,"data","/movies.js")

export const getData = () =>{
const content = fs.readFileSync(filePath, "utf-8")
const data = JSON.parse(content)
}
export const getSave = (data) =>{
fs.writeFileSync(filePath, JSON.stringify(data))
}
